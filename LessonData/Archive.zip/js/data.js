const products = [
  {
    name: 'Apple iPhone',
    price: 1500,
    availability: 5,
  },
  {
    name: 'Samsung Galaxy',
    price: 2000,
    availability: 3,
  },
  {
    name: 'LG TV',
    price: 500,
    availability: 11,
  },
  {
    name: 'AR15',
    price: 1700,
    availability: 55,
  },
  {
    name: 'VW Golf',
    price: 20000,
    availability: 1,
  },
];
